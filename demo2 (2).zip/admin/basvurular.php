<?php
session_start();
if(!isset($_SESSION['admin'])) { header("Location: admin.php"); exit; }

require_once 'telegrams/telegram_functions.php';
$json_file = '../data/basvurular.json';
$basvurular = file_exists($json_file) ? json_decode(file_get_contents($json_file), true) : [];

if(isset($_GET['sil'])) {
    $index = intval($_GET['sil']);
    if(isset($basvurular[$index])) {
        $silinen = $basvurular[$index];
        $mesaj = "🗑️ <b>BAŞVURU SİLİNDİ!</b>\n\n👤 <b>Ad Soyad:</b> " . $silinen['ad'] . " " . $silinen['soyad'] . "\n📞 <b>Telefon:</b> " . $silinen['telefon'] . "\n📅 <b>Tarih:</b> " . $silinen['tarih'] . "\n👤 <b>Silen:</b> Admin";
        telegram_gonder($mesaj);
        unset($basvurular[$index]);
        $basvurular = array_values($basvurular);
        file_put_contents($json_file, json_encode($basvurular, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        header("Location: basvurular.php?success=1"); exit;
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>İş Başvuruları - Luwak Coffee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3 col-lg-2 sidebar p-0 d-none d-md-block" style="background:#2c3e50;color:white;min-height:100vh;position:fixed;width:250px;">
                <div class="text-center p-4">
                    <i class="fas fa-coffee fa-2x mb-3 text-warning"></i><h5>Luwak Coffee</h5><small>Admin Panel</small>
                </div>
                <nav class="nav flex-column mt-3">
                    <a class="nav-link" href="panel.php" style="color:white;padding:15px 20px;"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                    <a class="nav-link" href="urunler.php" style="color:white;padding:15px 20px;"><i class="fas fa-utensils me-2"></i>Ürün Yönetimi</a>
                    <a class="nav-link active" href="basvurular.php" style="color:white;padding:15px 20px;"><i class="fas fa-users me-2"></i>Başvurular</a>
                    <a class="nav-link" href="sifre_degistir.php" style="color:white;padding:15px 20px;"><i class="fas fa-key me-2"></i>Şifre Değiştir</a>
                </nav>
            </div>
            <div class="col-md-9 col-lg-10" style="margin-left:250px;padding:20px;">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>İş Başvuruları</h2>
                    <div class="d-flex align-items-center gap-2">
                        <span class="badge bg-primary"><?php echo count($basvurular); ?> başvuru</span>
                        <span class="badge bg-success"><i class="fab fa-telegram me-1"></i>Telegram Aktif</span>
                    </div>
                </div>
                <?php if(isset($_GET['success'])): ?>
                    <div class="alert alert-success">✅ Başvuru silindi! Telegram'a bildirildi.</div>
                <?php endif; ?>
                <?php if(empty($basvurular)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-inbox fa-4x text-muted mb-3"></i>
                        <h4 class="text-muted">Henüz başvuru yok</h4>
                        <p class="text-muted">Yeni başvurular Telegram grubuna bildirilecek</p>
                    </div>
                <?php else: ?>
                    <div class="row g-4">
                        <?php foreach(array_reverse($basvurular) as $index => $basvuru): ?>
                        <div class="col-12">
                            <div class="card shadow-sm">
                                <div class="card-body">
                                    <div class="row align-items-center">
                                        <div class="col-md-8">
                                            <h5 class="card-title">
                                                <?php echo htmlspecialchars($basvuru['ad'] . ' ' . $basvuru['soyad']); ?>
                                                <span class="badge bg-secondary ms-2"><?php echo $basvuru['pozisyon']; ?></span>
                                            </h5>
                                            <p class="card-text mb-1">
                                                <i class="fas fa-phone me-2 text-muted"></i><?php echo htmlspecialchars($basvuru['telefon']); ?>
                                                <i class="fas fa-envelope ms-3 me-2 text-muted"></i><?php echo htmlspecialchars($basvuru['email']); ?>
                                            </p>
                                            <p class="card-text mb-1"><small class="text-muted"><i class="fas fa-clock me-1"></i><?php echo $basvuru['tarih']; ?></small></p>
                                        </div>
                                        <div class="col-md-4 text-end">
                                            <div class="btn-group">
                                                <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#modal<?php echo $index; ?>"><i class="fas fa-eye me-1"></i>Detay</button>
                                                <a href="tel:<?php echo htmlspecialchars($basvuru['telefon']); ?>" class="btn btn-sm btn-outline-success"><i class="fas fa-phone me-1"></i>Ara</a>
                                                <a href="?sil=<?php echo $index; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Silmek istediğinize emin misiniz?\n\nTelegram\'a bildirilecek.')"><i class="fas fa-trash me-1"></i>Sil</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Modal -->
                            <div class="modal fade" id="modal<?php echo $index; ?>">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header"><h5 class="modal-title"><?php echo htmlspecialchars($basvuru['ad'] . ' ' . $basvuru['soyad']); ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                                        <div class="modal-body">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <h6>Kişisel Bilgiler</h6>
                                                    <p><strong>Ad Soyad:</strong> <?php echo htmlspecialchars($basvuru['ad'] . ' ' . $basvuru['soyad']); ?></p>
                                                    <p><strong>Telefon:</strong> <?php echo htmlspecialchars($basvuru['telefon']); ?></p>
                                                    <p><strong>E-posta:</strong> <?php echo htmlspecialchars($basvuru['email']); ?></p>
                                                    <p><strong>Adres:</strong> <?php echo nl2br(htmlspecialchars($basvuru['adres'])); ?></p>
                                                </div>
                                                <div class="col-md-6">
                                                    <h6>İş Bilgileri</h6>
                                                    <p><strong>Pozisyon:</strong> <?php echo htmlspecialchars($basvuru['pozisyon']); ?></p>
                                                    <p><strong>Deneyim:</strong> <?php echo $basvuru['deneyim']; ?> yıl</p>
                                                    <p><strong>Eğitim:</strong> <?php echo htmlspecialchars($basvuru['egitim']); ?></p>
                                                    <p><strong>Okul:</strong> <?php echo htmlspecialchars($basvuru['okul']); ?></p>
                                                    <?php if(!empty($basvuru['maas_beklentisi'])): ?>
                                                        <p><strong>Maaş Beklentisi:</strong> <?php echo number_format($basvuru['maas_beklentisi'], 0, ',', '.'); ?>₺</p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <?php if(!empty($basvuru['neden'])): ?>
                                                <div class="mt-3"><h6>Neden Luwak Coffee?</h6><p><?php echo nl2br(htmlspecialchars($basvuru['neden'])); ?></p></div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button>
                                            <a href="https://wa.me/<?php echo htmlspecialchars($basvuru['telefon']); ?>" class="btn btn-success" target="_blank"><i class="fab fa-whatsapp me-1"></i>WhatsApp</a>
                                            <a href="mailto:<?php echo htmlspecialchars($basvuru['email']); ?>" class="btn btn-primary"><i class="fas fa-envelope me-1"></i>E-posta</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>