<?php
session_start();
if(!isset($_SESSION['admin'])) { header("Location: admin.php"); exit; }

$message = ''; $error = '';
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['degistir'])) {
    $mevcut_sifre = $_POST['mevcut_sifre'] ?? '';
    $yeni_sifre = $_POST['yeni_sifre'] ?? '';
    $yeni_sifre_tekrar = $_POST['yeni_sifre_tekrar'] ?? '';
    $mevcut_sifre_dogru = '1234';
    
    if($mevcut_sifre !== $mevcut_sifre_dogru) {
        $error = "Mevcut şifre hatalı!";
    } elseif($yeni_sifre !== $yeni_sifre_tekrar) {
        $error = "Yeni şifreler uyuşmuyor!";
    } elseif(strlen($yeni_sifre) < 4) {
        $error = "Yeni şifre en az 4 karakter olmalı!";
    } else {
        $message = "✅ Şifre başarıyla değiştirildi!<br><strong>Yeni Şifre: " . htmlspecialchars($yeni_sifre) . "</strong><br><br>Şifreyi kalıcı olarak değiştirmek için `admin.php` dosyasındaki `\$default_password` değişkenini güncellemen gerekiyor.";
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şifre Değiştir - Luwak Coffee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3 col-lg-2 sidebar p-0 d-none d-md-block" style="background:#2c3e50;color:white;min-height:100vh;position:fixed;width:250px;">
                <div class="text-center p-4">
                    <i class="fas fa-coffee fa-2x mb-3 text-warning"></i><h5>Luwak Coffee</h5><small>Admin Panel</small>
                </div>
                <nav class="nav flex-column mt-3">
                    <a class="nav-link" href="panel.php" style="color:white;padding:15px 20px;"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                    <a class="nav-link" href="urunler.php" style="color:white;padding:15px 20px;"><i class="fas fa-utensils me-2"></i>Ürün Yönetimi</a>
                    <a class="nav-link" href="basvurular.php" style="color:white;padding:15px 20px;"><i class="fas fa-users me-2"></i>Başvurular</a>
                    <a class="nav-link active" href="sifre_degistir.php" style="color:white;padding:15px 20px;"><i class="fas fa-key me-2"></i>Şifre Değiştir</a>
                </nav>
            </div>
            <div class="col-md-9 col-lg-10" style="margin-left:250px;padding:20px;">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Şifre Değiştir</h2>
                    <a href="panel.php" class="btn btn-secondary"><i class="fas fa-arrow-left me-2"></i>Geri Dön</a>
                </div>
                <div class="row justify-content-center">
                    <div class="col-md-6">
                        <div class="card shadow">
                            <div class="card-header bg-primary text-white">
                                <h5 class="card-title mb-0"><i class="fas fa-key me-2"></i>Admin Şifresini Değiştir</h5>
                            </div>
                            <div class="card-body p-4">
                                <?php if($error): ?><div class="alert alert-danger"><?php echo $error; ?></div><?php endif; ?>
                                <?php if($message): ?><div class="alert alert-success"><?php echo $message; ?></div><?php endif; ?>
                                <form method="POST">
                                    <div class="mb-3"><label class="form-label">Mevcut Şifre</label><input type="password" name="mevcut_sifre" class="form-control" required><small class="text-muted">Varsayılan şifre: <strong>1234</strong></small></div>
                                    <div class="mb-3"><label class="form-label">Yeni Şifre</label><input type="password" name="yeni_sifre" class="form-control" required><small class="text-muted">En az 4 karakter</small></div>
                                    <div class="mb-3"><label class="form-label">Yeni Şifre (Tekrar)</label><input type="password" name="yeni_sifre_tekrar" class="form-control" required></div>
                                    <button type="submit" name="degistir" class="btn btn-primary w-100 py-2"><i class="fas fa-save me-2"></i>Şifreyi Değiştir</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>