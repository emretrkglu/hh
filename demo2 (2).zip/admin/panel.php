<?php
session_start();
if(!isset($_SESSION['admin'])) { header("Location: admin.php"); exit; }

$json_file = '../data/urunler.json';
$urunler = file_exists($json_file) ? json_decode(file_get_contents($json_file), true) : [];

$toplam_urun = 0;
foreach($urunler as $urun_listesi) $toplam_urun += count($urun_listesi);

if(isset($_GET['logout'])) { session_destroy(); header("Location: admin.php"); exit; }

$kategori_isimler = [
    'nargileler' => '🤩 Nargileler', 'sicak_kahveler' => '☕ Sıcak Kahveler',
    'soguk_kahveler' => '🥤 Soğuk Kahveler', 'kokteyller' => '🍹 Kokteyller',
    'atistirmalik' => '🍟 Atıştırmalık', 'tatlilar' => '🍰 Tatlılar'
];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Luwak Coffee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .sidebar { background: #2c3e50; color: white; min-height: 100vh; width: 250px; position: fixed; }
        .sidebar .nav-link { color: white; padding: 15px 20px; border-bottom: 1px solid rgba(255,255,255,0.1); }
        .sidebar .nav-link:hover { background: rgba(255,255,255,0.1); }
        .main-content { margin-left: 250px; padding: 20px; background: #f8f9fa; min-height: 100vh; }
        .stat-card { background: white; border-radius: 15px; padding: 25px; text-align: center; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3 col-lg-2 sidebar p-0 d-none d-md-block">
                <div class="text-center p-4">
                    <i class="fas fa-coffee fa-2x mb-3 text-warning"></i>
                    <h5>Luwak Coffee</h5>
                    <small>Admin Panel</small>
                </div>
                <nav class="nav flex-column mt-3">
                    <a class="nav-link active" href="panel.php"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                    <a class="nav-link" href="urunler.php"><i class="fas fa-utensils me-2"></i>Ürün Yönetimi</a>
                    <a class="nav-link" href="basvurular.php"><i class="fas fa-users me-2"></i>İş Başvuruları</a>
                    <a class="nav-link" href="sifre_degistir.php"><i class="fas fa-key me-2"></i>Şifre Değiştir</a>
                    <a class="nav-link" href="../index.html" target="_blank"><i class="fas fa-eye me-2"></i>Siteyi Gör</a>
                    <a class="nav-link" href="?logout=1"><i class="fas fa-sign-out-alt me-2"></i>Çıkış</a>
                </nav>
            </div>
            <div class="col-md-9 col-lg-10 main-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h2 class="fw-bold">Admin Dashboard</h2>
                        <p class="text-muted">Hoş geldiniz, Admin</p>
                    </div>
                    <div class="d-flex gap-2">
                        <a href="urunler.php" class="btn btn-primary"><i class="fas fa-plus me-2"></i>Yeni Ürün</a>
                        <a href="../index.html" target="_blank" class="btn btn-outline-secondary"><i class="fas fa-external-link-alt me-2"></i>Siteyi Gör</a>
                    </div>
                </div>
                <div class="alert alert-info mb-4">
                    <i class="fab fa-telegram me-2"></i>
                    <strong>Telegram Grubu Aktif:</strong> Yeni başvurular gruba gönderiliyor.
                </div>
                <div class="row g-4">
                    <div class="col-xl-3 col-md-6"><div class="stat-card"><i class="fas fa-coffee fa-2x text-primary mb-3"></i><h3><?php echo $toplam_urun; ?></h3><p>Toplam Ürün</p></div></div>
                    <div class="col-xl-3 col-md-6"><div class="stat-card"><i class="fas fa-list fa-2x text-success mb-3"></i><h3>6</h3><p>Toplam Kategori</p></div></div>
                    <div class="col-xl-3 col-md-6"><div class="stat-card"><i class="fas fa-users fa-2x text-warning mb-3"></i><h3>0</h3><p>Başvuru</p></div></div>
                    <div class="col-xl-3 col-md-6"><div class="stat-card"><i class="fas fa-chart-line fa-2x text-info mb-3"></i><h3>Aktif</h3><p>Sistem Durumu</p><span class="badge bg-success">Çevrimiçi</span></div></div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>