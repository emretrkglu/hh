<?php
session_start();
$default_password = '1234';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $girilen_sifre = $_POST['password'] ?? '';
    
    if($girilen_sifre === $default_password) {
        $_SESSION['admin'] = true;
        header("Location: panel.php");
        exit;
    } else {
        $error = "Hatalı şifre! Varsayılan şifre: 1234";
    }
}

if(isset($_SESSION['admin'])) {
    header("Location: panel.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Giriş - Luwak Coffee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .login-container { min-height: 100vh; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; }
        .login-card { background: rgba(255,255,255,0.95); border-radius: 20px; padding: 40px; box-shadow: 0 20px 40px rgba(0,0,0,0.3); }
        .telegram-badge { background: #0088cc; color: white; padding: 10px; border-radius: 10px; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-5">
                    <div class="login-card">
                        <div class="text-center mb-4">
                            <i class="fas fa-coffee fa-3x text-primary mb-3"></i>
                            <h2>Luwak Coffee</h2>
                            <p class="text-muted">Admin Panel Giriş</p>
                            <div class="telegram-badge">
                                <i class="fab fa-telegram me-2"></i>
                                <strong>Telegram Grubu Aktif!</strong>
                            </div>
                        </div>
                        <?php if(isset($error)): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        <form method="POST">
                            <div class="mb-3">
                                <label>Admin Şifresi</label>
                                <input type="password" name="password" class="form-control" required placeholder="Varsayılan: 1234">
                            </div>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-sign-in-alt me-2"></i>Giriş Yap
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>