<?php
session_start();
// Dosya yükleme fonksiyonu
function resimYukle($dosya, $urunAd) {
    $hedefKlasor = '../uploads/';
    
    // uploads klasörü yoksa oluştur
    if(!file_exists($hedefKlasor)) {
        mkdir($hedefKlasor, 0755, true);
    }
    
    // Güvenlik kontrolleri
    $izinliTurler = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/jpg'];
    $maksimumBoyut = 5 * 1024 * 1024; // 5MB
    
    if($dosya['error'] !== UPLOAD_ERR_OK) {
        return null; // Dosya yükleme hatası
    }
    
    if(!in_array($dosya['type'], $izinliTurler)) {
        return null; // İzin verilmeyen dosya türü
    }
    
    if($dosya['size'] > $maksimumBoyut) {
        return null; // Dosya çok büyük
    }
    
    // Dosya adını güvenli hale getir
    $dosyaAdi = time() . '_' . preg_replace('/[^a-zA-Z0-9\._-]/', '', $dosya['name']);
    $hedefYol = $hedefKlasor . $dosyaAdi;
    
    // Dosyayı taşı
    if(move_uploaded_file($dosya['tmp_name'], $hedefYol)) {
        return $hedefYol; // Başarılı
    }
    
    return null; // Başarısız
}
if(!isset($_SESSION['admin'])) { header("Location: admin.php"); exit; }

$json_file = '../data/urunler.json';
$urunler = file_exists($json_file) ? json_decode(file_get_contents($json_file), true) : [];

$kategoriler = ['nargileler', 'sicak_kahveler', 'soguk_kahveler', 'kokteyller', 'atistirmalik', 'tatlilar'];
foreach($kategoriler as $kategori) { if(!isset($urunler[$kategori])) $urunler[$kategori] = []; }

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['ekle'])) {
    $kategori = $_POST['kategori'];
    $resimYolu = '';
    
    // 1. Önce dosya yüklemesi kontrol et
    if(isset($_FILES['resim_dosya']) && $_FILES['resim_dosya']['error'] == UPLOAD_ERR_OK) {
        $resimYolu = resimYukle($_FILES['resim_dosya'], $_POST['ad']);
    }
    
    // 2. Eğer dosya yüklenmediyse link kontrol et
    if(empty($resimYolu) && !empty(trim($_POST['resim_link']))) {
        $resimYolu = trim($_POST['resim_link']);
    }
    
    // 3. Hiçbiri yoksa placeholder kullan
    if(empty($resimYolu)) {
        $resimYolu = 'https://via.placeholder.com/400x250/667eea/ffffff?text=' . urlencode($_POST['ad']);
    }
    
    $urunler[$kategori][] = [
        'id' => time(),
        'ad' => trim($_POST['ad']),
        'fiyat' => floatval($_POST['fiyat']),
        'resim' => $resimYolu
    ];
    
    file_put_contents($json_file, json_encode($urunler, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    header("Location: urunler.php?success=1&kategori=$kategori"); 
    exit;
}
if(isset($_GET['sil'])) {
    $kategori = $_GET['kategori']; $id = intval($_GET['sil']);
    $urunler[$kategori] = array_filter($urunler[$kategori], function($urun) use ($id) { return $urun['id'] != $id; });
    file_put_contents($json_file, json_encode($urunler, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    header("Location: urunler.php?success=2&kategori=$kategori"); exit;
}

$kategori_isimler = [
    'nargileler' => '🤩 Nargileler', 'sicak_kahveler' => '☕ Sıcak Kahveler',
    'soguk_kahveler' => '🥤 Soğuk Kahveler', 'kokteyller' => '🍹 Kokteyller',
    'atistirmalik' => '🍟 Atıştırmalık', 'tatlilar' => '🍰 Tatlılar'
];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ürün Yönetimi - Luwak Coffee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3 col-lg-2 sidebar p-0 d-none d-md-block" style="background:#2c3e50;color:white;min-height:100vh;position:fixed;width:250px;">
                <div class="text-center p-4">
                    <i class="fas fa-coffee fa-2x mb-3 text-warning"></i><h5>Luwak Coffee</h5><small>Admin Panel</small>
                </div>
                <nav class="nav flex-column mt-3">
                    <a class="nav-link" href="panel.php" style="color:white;padding:15px 20px;"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                    <a class="nav-link active" href="urunler.php" style="color:white;padding:15px 20px;"><i class="fas fa-utensils me-2"></i>Ürün Yönetimi</a>
                    <a class="nav-link" href="basvurular.php" style="color:white;padding:15px 20px;"><i class="fas fa-users me-2"></i>Başvurular</a>
                    <a class="nav-link" href="sifre_degistir.php" style="color:white;padding:15px 20px;"><i class="fas fa-key me-2"></i>Şifre Değiştir</a>
                </nav>
            </div>
            <div class="col-md-9 col-lg-10" style="margin-left:250px;padding:20px;">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Ürün Yönetimi</h2>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#urunEkleModal"><i class="fas fa-plus me-2"></i>Yeni Ürün</button>
                </div>
                <?php if(isset($_GET['success'])): ?>
                    <div class="alert alert-success"><?php echo $_GET['success'] == 1 ? '✅ Ürün eklendi!' : '✅ Ürün silindi!'; ?></div>
                <?php endif; ?>
                <?php foreach($kategori_isimler as $kategori => $isim): ?>
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><?php echo $isim; ?></h5>
                        <span class="badge bg-primary"><?php echo count($urunler[$kategori]); ?> ürün</span>
                    </div>
                    <div class="card-body">
                        <?php if(empty($urunler[$kategori])): ?>
                            <p class="text-muted text-center py-3">Henüz ürün yok</p>
                        <?php else: ?>
                            <div class="row">
                                <?php foreach($urunler[$kategori] as $urun): ?>
                                <div class="col-md-6 col-lg-4 mb-3">
                                    <div class="border rounded p-3">
                                        <div class="row align-items-center">
                                            <div class="col-4"><img src="<?php echo $urun['resim']; ?>" class="img-fluid rounded" style="height:80px;object-fit:cover;" onerror="this.src='https://via.placeholder.com/80'"></div>
                                            <div class="col-6">
                                                <h6 class="fw-bold mb-1"><?php echo $urun['ad']; ?></h6>
                                                <p class="text-success fw-bold mb-0"><?php echo $urun['fiyat']; ?>₺</p>
                                            </div>
                                            <div class="col-2">
                                                <a href="?sil=<?php echo $urun['id']; ?>&kategori=<?php echo $kategori; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Silmek istediğinize emin misiniz?')"><i class="fas fa-trash"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="urunEkleModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header"><h5 class="modal-title">Yeni Ürün Ekle</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                <form method="POST">
                    <div class="modal-body">
                        <div class="mb-3"><label>Kategori</label><select name="kategori" class="form-select" required>
                            <?php foreach($kategori_isimler as $kategori => $isim): ?>
                                <option value="<?php echo $kategori; ?>"><?php echo $isim; ?></option>
                            <?php endforeach; ?>
                        </select></div>
                        <div class="mb-3"><label>Ürün Adı</label><input type="text" name="ad" class="form-control" required></div>
                        <div class="mb-3"><label>Fiyat (₺)</label><input type="number" name="fiyat" class="form-control" step="0.01" required></div>
                  <!-- Resim Yükleme Seçenekleri -->
<div class="mb-3">
    <label>Resim Ekle</label>
    
    <!-- Seçenekler -->
    <div class="mb-2">
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="resim_secenek" id="dosyaSec" value="dosya" checked onclick="resimSecimDegisti()">
            <label class="form-check-label" for="dosyaSec">Dosya Yükle</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="resim_secenek" id="linkSec" value="link" onclick="resimSecimDegisti()">
            <label class="form-check-label" for="linkSec">Link Kullan</label>
        </div>
    </div>
    
    <!-- Dosya Yükleme -->
    <div id="dosyaAlani" class="mt-2">
        <input type="file" name="resim_dosya" class="form-control" accept="image/*">
        <small class="text-muted">JPEG, PNG, GIF, WebP (Max: 5MB)</small>
    </div>
    
    <!-- Link Girişi -->
    <div id="linkAlani" class="mt-2" style="display:none;">
        <input type="url" name="resim_link" class="form-control" placeholder="https://example.com/resim.jpg">
        <small class="text-muted">Harici resim linki</small>
    </div>
</div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                        <button type="submit" name="ekle" class="btn btn-primary">Ekle</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
 <script>
function resimSecimDegisti() {
    var dosyaSecildi = document.querySelector('input[name="resim_secenek"]:checked').value === 'dosya';
    
    document.getElementById('dosyaAlani').style.display = dosyaSecildi ? 'block' : 'none';
    document.getElementById('linkAlani').style.display = dosyaSecildi ? 'none' : 'block';
    
    // Zorunlu alan ayarı
    document.querySelector('input[name="resim_dosya"]').required = dosyaSecildi;
    document.querySelector('input[name="resim_link"]').required = !dosyaSecildi;
}

// Sayfa yüklendiğinde başlangıç durumunu ayarla
document.addEventListener('DOMContentLoaded', function() {
    resimSecimDegisti();
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
</body>
</html>