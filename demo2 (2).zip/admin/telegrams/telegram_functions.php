<?php
require_once 'telegram_config.php';

function telegram_gonder($mesaj) {
    $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendMessage";
    
    $data = [
        'chat_id' => TELEGRAM_CHAT_ID,
        'text' => $mesaj,
        'parse_mode' => 'HTML',
        'disable_web_page_preview' => false
    ];
    
    $options = [
        'http' => [
            'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
            'method' => 'POST',
            'content' => http_build_query($data),
        ],
    ];
    
    $context = stream_context_create($options);
    @file_get_contents($url, false, $context);
    return true;
}

function basvuru_telegram_mesaji($basvuru) {
    $mesaj = "🚀 <b>YENİ İŞ BAŞVURUSU!</b>\n\n";
    $mesaj .= "👤 <b>Ad Soyad:</b> " . htmlspecialchars($basvuru['ad'] . " " . $basvuru['soyad']) . "\n";
    $mesaj .= "📞 <b>Telefon:</b> " . htmlspecialchars($basvuru['telefon']) . "\n";
    $mesaj .= "📧 <b>E-posta:</b> " . htmlspecialchars($basvuru['email']) . "\n";
    
    if (!empty($basvuru['adres'])) {
        $mesaj .= "📍 <b>Adres:</b> " . htmlspecialchars($basvuru['adres']) . "\n";
    }
    
    $mesaj .= "💼 <b>Pozisyon:</b> " . htmlspecialchars($basvuru['pozisyon']) . "\n";
    $mesaj .= "🎯 <b>Deneyim:</b> " . htmlspecialchars($basvuru['deneyim']) . " yıl\n";
    
    if (!empty($basvuru['onceki_deneyim'])) {
        $mesaj .= "📋 <b>Önceki Deneyim:</b> " . htmlspecialchars($basvuru['onceki_deneyim']) . "\n";
    }
    
    if (!empty($basvuru['egitim'])) {
        $mesaj .= "🎓 <b>Eğitim:</b> " . htmlspecialchars($basvuru['egitim']) . "\n";
    }
    
    if (!empty($basvuru['okul'])) {
        $mesaj .= "🏫 <b>Okul:</b> " . htmlspecialchars($basvuru['okul']) . "\n";
    }
    
    if (!empty($basvuru['maas_beklentisi'])) {
        $maas_formatli = number_format($basvuru['maas_beklentisi'], 0, ',', '.');
        $mesaj .= "💰 <b>Maaş Beklentisi:</b> " . $maas_formatli . "₺\n";
    }
    
    if (!empty($basvuru['neden'])) {
        $neden_kisa = strlen($basvuru['neden']) > 100 ? substr($basvuru['neden'], 0, 100) . "..." : $basvuru['neden'];
        $mesaj .= "❓ <b>Neden:</b> " . htmlspecialchars($neden_kisa) . "\n";
    }
    
    if (!empty($basvuru['cv_dosya'])) {
        $mesaj .= "📎 <b>CV:</b> " . htmlspecialchars($basvuru['cv_bilgi']) . "\n";
    } else {
        $mesaj .= "📎 <b>CV:</b> Yüklenmedi\n";
    }
    
    $mesaj .= "\n📅 <b>Tarih:</b> " . $basvuru['tarih'];
    
    return $mesaj;
}
?>