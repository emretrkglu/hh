<?php
// TELEGRAM BOT AYARLARI - GRUP BAĞLANTISI
define('TELEGRAM_BOT_TOKEN', '8555098255:AAG61tZftd08IQf_xAa1Sts7ETc_waPfycw');
define('TELEGRAM_CHAT_ID', '-1003216887957'); // Luwak Coffee Başvurular Grubu

// WHATSAPP VE SOSYAL MEDYA AYARLARI
define('WHATSAPP_NUMBER', '905070820505'); // Luwak Coffee WhatsApp
define('INSTAGRAM_USERNAME', 'luwak_tr'); // Instagram kullanıcı adı
define('PHONE_NUMBER', '+905070820505'); // Telefon numarası
define('ADDRESS', 'Mimarsinan, Atatürk Bl. No:194, 55200 Atakum/Samsun');
define('MAPS_LINK', 'https://www.google.com/maps/dir//Mimarsinan,+Atat%C3%BCrk+Bl.+No:194,+55200+Atakum%2FSamsun/@40.6539128,35.8203729,15z/data=!3m1!4b1!4m8!4m7!1m0!1m5!1m1!1s0x408879a8532cbe9d:0x3ebe8c152915a76c!2m2!1d36.2830557!2d41.3336111?entry=ttu&g_ep=EgoyMDI1MTIwOS4wIKXMDSoASAFQAw%3D%3D');
?>