<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>İş Başvurusu - Luwak Coffee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .application-hero { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 80px 0 50px; text-align: center; }
        .application-form { background: white; border-radius: 20px; padding: 40px; margin: -50px auto 50px; box-shadow: 0 20px 40px rgba(0,0,0,0.1); max-width: 800px; }
        .form-section { border-left: 4px solid #667eea; padding-left: 20px; margin-bottom: 30px; }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="../index.html">
                <i class="fas fa-arrow-left me-2"></i>Luwak Coffee
            </a>
            <div>
                <a href="../index.html" class="btn btn-outline-light me-2">Ana Sayfa</a>
                <a href="../pages/menu.html" class="btn btn-outline-light">Menü</a>
            </div>
        </div>
    </nav>

    <section class="application-hero">
        <div class="container">
            <h1 class="display-4 fw-bold mb-3">🎯 İş Başvurusu</h1>
            <p class="lead mb-0">Luwak Coffee ailesine katılmak ister misin?</p>
        </div>
    </section>

    <div class="container">
        <div class="application-form">
            <form id="applicationForm" action="isbasvuru_gonder.php" method="POST" enctype="multipart/form-data">
                <div class="form-section">
                    <h4 class="fw-bold mb-4">👤 Kişisel Bilgiler</h4>
                    <div class="row g-3">
                        <div class="col-md-6"><label class="form-label">Adınız *</label><input type="text" name="ad" class="form-control" required></div>
                        <div class="col-md-6"><label class="form-label">Soyadınız *</label><input type="text" name="soyad" class="form-control" required></div>
                        <div class="col-md-6"><label class="form-label">Telefon *</label><input type="tel" name="telefon" class="form-control" required></div>
                        <div class="col-md-6"><label class="form-label">E-posta *</label><input type="email" name="email" class="form-control" required></div>
                        <div class="col-12"><label class="form-label">Adres</label><textarea name="adres" class="form-control" rows="2"></textarea></div>
                    </div>
                </div>

                <div class="form-section">
                    <h4 class="fw-bold mb-4">💼 İş Deneyimi</h4>
                    <div class="row g-3">
                        <div class="col-md-6"><label class="form-label">Pozisyon *</label>
                            <select name="pozisyon" class="form-select" required>
                                <option value="">Seçiniz</option><option value="barista">Barista</option><option value="garson">Garson</option>
                                <option value="kasiyer">Kasiyer</option><option value="temizlik">Temizlik Personeli</option>
                                <option value="yonetici">Şube Yöneticisi</option><option value="diger">Diğer</option>
                            </select>
                        </div>
                        <div class="col-md-6"><label class="form-label">Deneyim (Yıl)</label>
                            <select name="deneyim" class="form-select">
                                <option value="0">0 (Yeni başlayan)</option><option value="1">0-1 Yıl</option><option value="2">1-2 Yıl</option>
                                <option value="3">2-3 Yıl</option><option value="5">3-5 Yıl</option><option value="10">5+ Yıl</option>
                            </select>
                        </div>
                        <div class="col-12"><label class="form-label">Önceki İş Deneyimleri</label><textarea name="onceki_deneyim" class="form-control" rows="3" placeholder="Varsa önceki iş deneyimlerinizi kısaca yazın..."></textarea></div>
                    </div>
                </div>

                <div class="form-section">
                    <h4 class="fw-bold mb-4">🎓 Eğitim Bilgileri</h4>
                    <div class="row g-3">
                        <div class="col-md-6"><label class="form-label">Eğitim Durumu</label>
                            <select name="egitim" class="form-select">
                                <option value="">Seçiniz</option><option value="ilkokul">İlkokul</option><option value="ortaokul">Ortaokul</option>
                                <option value="lise">Lise</option><option value="onlisans">Önlisans</option><option value="lisans">Lisans</option>
                                <option value="yukseklisans">Yüksek Lisans</option>
                            </select>
                        </div>
                        <div class="col-md-6"><label class="form-label">Mezun Olduğu Okul</label><input type="text" name="okul" class="form-control"></div>
                    </div>
                </div>

                <div class="form-section">
                    <h4 class="fw-bold mb-4">📋 Ek Bilgiler</h4>
                    <div class="row g-3">
                        <div class="col-12"><label class="form-label">Neden Luwak Coffee'de çalışmak istiyorsunuz? *</label><textarea name="neden" class="form-control" rows="3" required></textarea></div>
                        <div class="col-12"><label class="form-label">Maaş Beklentisi (TL)</label><input type="number" name="maas_beklentisi" class="form-control" placeholder="Örn: 15000"></div>
                        <div class="col-12"><label class="form-label">CV Yükle (PDF, DOC, DOCX - Max 2MB)</label><input type="file" name="cv" class="form-control" accept=".pdf,.doc,.docx"></div>
                        <div class="col-12">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="kvkk" required>
                                <label class="form-check-label"><a href="#" data-bs-toggle="modal" data-bs-target="#kvkkModal">KVKK Aydınlatma Metni</a>'ni okudum ve kabul ediyorum *</label>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="text-center mt-4">
                    <button type="submit" class="btn btn-primary btn-lg px-5"><i class="fas fa-paper-plane me-2"></i>Başvuruyu Gönder</button>
                </div>
            </form>
        </div>
    </div>

    <!-- KVKK Modal -->
    <div class="modal fade" id="kvkkModal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header"><h5 class="modal-title">KVKK Aydınlatma Metni</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                <div class="modal-body">
                    <p>Kişisel verileriniz, 6698 sayılı Kişisel Verilerin Korunması Kanunu kapsamında işlenmektedir.</p>
                    <p><strong>Veri Sorumlusu:</strong> Luwak Coffee</p>
                    <p><strong>İşlenen Veriler:</strong> Ad, soyad, telefon, e-posta, adres, iş deneyimi, eğitim bilgileri</p>
                    <p><strong>Amaç:</strong> İş başvurusu değerlendirme süreci</p>
                    <p><strong>Saklama Süresi:</strong> 2 yıl</p>
                    <p>Detaylı bilgi için: info@luwakcoffee.com</p>
                </div>
                <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button></div>
            </div>
        </div>
    </div>

    <footer class="bg-dark text-white py-4">
        <div class="container text-center">
            <p class="mb-2">📞 İletişim: <a href="tel:+905070820505" class="text-warning">+90 507 082 05 05</a></p>
            <p class="mb-0">© 2024 Luwak Coffee - Kariyer</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('applicationForm').addEventListener('submit', function(e) {
            const fileInput = document.querySelector('input[name="cv"]');
            if(fileInput.files.length > 0) {
                const fileSize = fileInput.files[0].size / 1024 / 1024;
                if(fileSize > 2) { e.preventDefault(); alert('CV dosyası 2MB\'dan büyük olamaz!'); return false; }
            }
            if(!document.querySelector('input[name="kvkk"]').checked) {
                e.preventDefault(); alert('KVKK aydınlatma metnini kabul etmelisiniz!'); return false;
            }
        });
    </script>
</body>
</html>