<?php
require_once '../admin/telegrams/telegram_functions.php';

$cv_dosya_adi = ''; $cv_bilgisi = '';
if(isset($_FILES['cv']) && $_FILES['cv']['error'] === UPLOAD_ERR_OK) {
    $cv_uzanti = strtolower(pathinfo($_FILES['cv']['name'], PATHINFO_EXTENSION));
    $izinli_uzantilar = ['pdf', 'doc', 'docx'];
    if(in_array($cv_uzanti, $izinli_uzantilar)) {
        $dosya_boyutu = $_FILES['cv']['size'] / 1024 / 1024;
        if($dosya_boyutu <= 2) {
            $yeni_dosya_adi = 'cv_' . time() . '_' . rand(1000, 9999) . '.' . $cv_uzanti;
            $hedef_dizin = '../uploads/cv_uploads/';
            if(!is_dir($hedef_dizin)) mkdir($hedef_dizin, 0755, true);
            $hedef_yol = $hedef_dizin . $yeni_dosya_adi;
            if(move_uploaded_file($_FILES['cv']['tmp_name'], $hedef_yol)) {
                $cv_dosya_adi = $yeni_dosya_adi;
                $cv_bilgisi = $_FILES['cv']['name'] . ' (' . round($dosya_boyutu, 2) . ' MB)';
            }
        }
    }
}

$basvuru_data = [
    'tarih' => date('d.m.Y H:i:s'),
    'ad' => trim($_POST['ad'] ?? ''),
    'soyad' => trim($_POST['soyad'] ?? ''),
    'telefon' => trim($_POST['telefon'] ?? ''),
    'email' => trim($_POST['email'] ?? ''),
    'adres' => trim($_POST['adres'] ?? ''),
    'pozisyon' => trim($_POST['pozisyon'] ?? ''),
    'deneyim' => trim($_POST['deneyim'] ?? '0'),
    'onceki_deneyim' => trim($_POST['onceki_deneyim'] ?? ''),
    'egitim' => trim($_POST['egitim'] ?? ''),
    'okul' => trim($_POST['okul'] ?? ''),
    'neden' => trim($_POST['neden'] ?? ''),
    'maas_beklentisi' => trim($_POST['maas_beklentisi'] ?? ''),
    'cv_dosya' => $cv_dosya_adi,
    'cv_bilgi' => $cv_bilgisi
];

$telegram_mesaj = basvuru_telegram_mesaji($basvuru_data);
telegram_gonder($telegram_mesaj);

$json_file = '../data/basvurular.json';
$tum_basvurular = file_exists($json_file) ? json_decode(file_get_contents($json_file), true) : [];
$tum_basvurular[] = $basvuru_data;
file_put_contents($json_file, json_encode($tum_basvurular, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Başvurunuz Alındı - Luwak Coffee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body style="background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); min-height: 100vh; display: flex; align-items: center;">
    <div class="container">
        <div class="card shadow-lg mx-auto" style="max-width: 500px; border-radius: 20px;">
            <div class="card-body p-5 text-center">
                <div style="width:100px;height:100px;background:#28a745;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 30px;color:white;font-size:40px;">
                    <i class="fas fa-check"></i>
                </div>
                <h1 class="fw-bold mb-3">Başvurunuz Alındı</h1>
                <p class="lead mb-4">Teşekkür ederiz! Başvurunuz başarıyla kaydedildi.<br>En kısa sürede sizinle iletişime geçeceğiz.</p>
                <?php if(!empty($cv_dosya_adi)): ?>
                    <div class="alert alert-success mb-3"><i class="fas fa-file-pdf me-2"></i>CV'niz başarıyla yüklendi</div>
                <?php endif; ?>
                <div class="alert alert-info mb-4">
                    <i class="fab fa-telegram me-2"></i>
                    <strong>Telegram Grubuna Bildirildi!</strong>
                </div>
                <div class="d-flex flex-column flex-sm-row justify-content-center gap-3">
                    <a href="../index.html" class="btn btn-primary"><i class="fas fa-home me-2"></i>Ana Sayfa</a>
                    <a href="../pages/menu.html" class="btn btn-outline-primary"><i class="fas fa-utensils me-2"></i>Menüyü İncele</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>